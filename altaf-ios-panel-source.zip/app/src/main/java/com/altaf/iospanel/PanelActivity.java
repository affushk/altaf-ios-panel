package com.altaf.iospanel;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.camera2.*;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.view.*;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import java.util.function.Consumer;

public class PanelActivity extends Activity {
    private LinearLayout root, body;
    private boolean notifications, closing, torchOn, torchRegistered;
    private CameraManager camera;
    private String flashId;
    private TextView torchButton;
    private AudioManager audio;
    private Consumer<Boolean> blurListener;
    private final Runnable notificationUpdate = () -> { if(notifications && body!=null && !isFinishing()) showNotifications(); };
    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override public void onTorchModeChanged(String id,boolean enabled) { if(id.equals(flashId)) { torchOn=enabled; updateTorch(); } }
        @Override public void onTorchModeUnavailable(String id) { if(id.equals(flashId)) { torchOn=false; updateTorch(); } }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        audio=getSystemService(AudioManager.class); camera=getSystemService(CameraManager.class);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setDimAmount(0.2f);
        getWindow().setStatusBarColor(Color.TRANSPARENT); getWindow().setNavigationBarColor(0xff172235);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        root=Ui.column(this); root.setPadding(Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24));
        root.setBackground(Ui.bg(this,0xed152239,0)); scroll.addView(root); setContentView(scroll);
        // Account for enforced edge-to-edge on Android 15 and display cutouts.
        scroll.setOnApplyWindowInsetsListener((v,insets)-> {
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets;
        });
        scroll.requestApplyInsets();
        TextClock clock=new TextClock(this); clock.setFormat12Hour("h:mm"); clock.setFormat24Hour("HH:mm"); clock.setTextSize(48); clock.setTextColor(Color.WHITE); root.addView(clock);
        TextClock date=new TextClock(this); date.setFormat12Hour("EEEE, d MMMM"); date.setFormat24Hour("EEEE, d MMMM"); date.setTextSize(15); date.setTextColor(0xffc4d5ee); root.addView(date); Ui.gap(root,22);
        LinearLayout tabs=new LinearLayout(this);
        addTile(tabs,"Controls",()-> { notifications=false; showControls(); });
        addTile(tabs,"Notifications",()-> { notifications=true; showNotifications(); }); root.addView(tabs); Ui.gap(root,12);
        body=Ui.column(this); root.addView(body); Ui.gap(root,18);
        root.addView(Ui.button(this,"Close panel  ×",this::close));
        TextView hint=Ui.text(this,"ALTAF  /  iOS INSPIRED",11,true); hint.setGravity(Gravity.CENTER); root.addView(hint);
        root.setAlpha(0); root.setTranslationY(-Ui.dp(this,20)); root.animate().alpha(1).translationY(0).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
        if(Build.VERSION.SDK_INT>=31) {
            blurListener=enabled -> applyBlur(enabled);
            try { getWindowManager().addCrossWindowBlurEnabledListener(blurListener); applyBlur(getWindowManager().isCrossWindowBlurEnabled()); }
            catch(RuntimeException ignored) { applyBlur(false); }
        }
        if(camera!=null) try {
            for(String id:camera.getCameraIdList()) {
                CameraCharacteristics c=camera.getCameraCharacteristics(id);
                if(Boolean.TRUE.equals(c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE))) { flashId=id; break; }
            }
            camera.registerTorchCallback(torchCallback,new Handler(Looper.getMainLooper())); torchRegistered=true;
        } catch(CameraAccessException | SecurityException ignored) { }
        showControls();
    }
    private void applyBlur(boolean enabled) {
        if(Build.VERSION.SDK_INT<31) return;
        WindowManager.LayoutParams p=getWindow().getAttributes();
        if(enabled) { p.flags|=WindowManager.LayoutParams.FLAG_BLUR_BEHIND; p.setBlurBehindRadius(Ui.dp(this,35)); }
        else { p.flags &= ~WindowManager.LayoutParams.FLAG_BLUR_BEHIND; p.setBlurBehindRadius(0); }
        getWindow().setAttributes(p);
        root.setBackground(Ui.bg(this,enabled?0x99152239:0xed152239,0));
    }
    private void addTile(LinearLayout row,String label,Runnable action) {
        TextView t=Ui.button(this,label,action); t.setGravity(Gravity.CENTER); t.setMinHeight(Ui.dp(this,76));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.setMargins(Ui.dp(this,4),Ui.dp(this,4),Ui.dp(this,4),Ui.dp(this,4)); row.addView(t,p);
    }
    private LinearLayout row() { LinearLayout r=new LinearLayout(this); body.addView(r,new LinearLayout.LayoutParams(-1,Ui.dp(this,92))); return r; }
    private void settings(String action) {
        try { startActivity(new Intent(action)); }
        catch(RuntimeException e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch(RuntimeException ignored) { Ui.toast(this,"Phone Settings kholein."); } }
    }
    private void showControls() {
        body.removeAllViews(); torchButton=null;
        LinearLayout r=row();
        addTile(r,"Wi-Fi\nSettings",()->settings(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_WIFI:Settings.ACTION_WIFI_SETTINGS));
        addTile(r,"Bluetooth\nSettings",()->settings(Settings.ACTION_BLUETOOTH_SETTINGS));
        r=row();
        addTile(r,"Mobile data\nSettings",()->settings(Build.VERSION.SDK_INT>=29?Settings.Panel.ACTION_INTERNET_CONNECTIVITY:Settings.ACTION_DATA_ROAMING_SETTINGS));
        addTile(r,"Airplane mode\nSettings",()->settings(Settings.ACTION_AIRPLANE_MODE_SETTINGS));
        Ui.gap(body,16);
        int bright=Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,128);
        SeekBar brightness=slider("Brightness",255,bright,progress -> {
            if(!Settings.System.canWrite(this)) return;
            try {
                Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE,Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,Math.max(10,progress));
            } catch(SecurityException e) { Ui.toast(this,"Brightness permission allow karein."); }
        });
        brightness.setEnabled(Settings.System.canWrite(this));
        if(!Settings.System.canWrite(this)) body.addView(Ui.button(this,"Allow brightness control",()-> {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName()))); }
            catch(RuntimeException e) { settings(Settings.ACTION_DISPLAY_SETTINGS); }
        }));
        Ui.gap(body,12);
        slider("Media volume",audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),audio.getStreamVolume(AudioManager.STREAM_MUSIC),progress -> {
            try { audio.setStreamVolume(AudioManager.STREAM_MUSIC,progress,0); } catch(SecurityException e) { Ui.toast(this,"Volume phone ke buttons se badlein."); }
        });
        Ui.gap(body,16);
        torchButton=Ui.button(this,"Flashlight",this::toggleTorch); body.addView(torchButton); updateTorch();
        body.addView(Ui.button(this,"Do Not Disturb settings",()->settings(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)));
        body.addView(Ui.text(this,"Network buttons asli Android settings kholte hain. Brightness slider auto-brightness ko manual karta hai.",12,false));
    }
    private interface Progress { void change(int value); }
    private SeekBar slider(String label,int max,int current,Progress callback) {
        LinearLayout card=Ui.column(this); card.setPadding(Ui.dp(this,16),Ui.dp(this,14),Ui.dp(this,16),Ui.dp(this,12)); card.setBackground(Ui.bg(this,0xcc31415b,22));
        card.addView(Ui.text(this,label,15,true)); SeekBar seek=new SeekBar(this); seek.setMax(max); seek.setProgress(current);
        card.addView(seek,new LinearLayout.LayoutParams(-1,Ui.dp(this,48))); body.addView(card);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b,int progress,boolean fromUser) { if(fromUser) callback.change(progress); }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { }
        }); return seek;
    }
    private void updateTorch() { if(torchButton!=null) torchButton.setText(flashId==null?"Flashlight unavailable":"Flashlight  ·  "+(torchOn?"On":"Off")); }
    private void toggleTorch() {
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.CAMERA},20); return; }
        if(flashId==null || camera==null) { Ui.toast(this,"Flashlight available nahi hai."); return; }
        try { camera.setTorchMode(flashId,!torchOn); } catch(CameraAccessException | RuntimeException e) { Ui.toast(this,"Flashlight abhi unavailable hai. Camera app band karke try karein."); }
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==20 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) toggleTorch();
    }
    private void showNotifications() {
        body.removeAllViews(); torchButton=null;
        body.addView(Ui.text(this,"Notification Center",24,true)); Ui.gap(body,14);
        if(NotificationBridge.instance==null) {
            body.addView(Ui.text(this,"Notification access allow karein. Agar pehle allowed hai to kuch seconds baad panel dobara kholein.",16,false));
            body.addView(Ui.button(this,"Notification access",()->settings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))); return;
        }
        int count=0;
        for(StatusBarNotification sbn:NotificationBridge.snapshot()) {
            if(sbn.getPackageName().equals(getPackageName())) continue;
            Notification n=sbn.getNotification();
            if((n.flags & Notification.FLAG_GROUP_SUMMARY)!=0) continue;
            count++;
            LinearLayout card=Ui.column(this); card.setPadding(Ui.dp(this,16),Ui.dp(this,14),Ui.dp(this,16),Ui.dp(this,12)); card.setBackground(Ui.bg(this,0xe83b4a61,22));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=Ui.dp(this,10); body.addView(card,p);
            String app=sbn.getPackageName();
            try { app=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(app,0)).toString(); } catch(PackageManager.NameNotFoundException ignored) { }
            card.addView(Ui.text(this,app+"  ·  "+android.text.format.DateFormat.format("HH:mm",sbn.getPostTime()),12,true)); Ui.gap(card,6);
            CharSequence title=n.extras.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text=n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if(text==null) text=n.extras.getCharSequence(Notification.EXTRA_TEXT);
            if(title!=null) { TextView t=Ui.text(this,title.toString(),17,true); t.setMaxLines(2); card.addView(t); }
            if(text!=null) { TextView t=Ui.text(this,text.toString(),15,false); t.setMaxLines(5); card.addView(t); }
            card.setOnClickListener(v->openNotification(sbn)); card.setFocusable(true);
            if(sbn.isClearable()) {
                TextView dismiss=Ui.text(this,"Dismiss",12,true); dismiss.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,6));
                dismiss.setOnClickListener(v->NotificationBridge.dismiss(sbn.getKey())); card.addView(dismiss);
            }
        }
        if(count==0) body.addView(Ui.text(this,"Abhi koi notification nahi hai. Kisi doosre phone se message bhejkar check karein.",16,false));
    }
    private void openNotification(StatusBarNotification sbn) {
        PendingIntent pi=sbn.getNotification().contentIntent;
        try {
            if(pi!=null) {
                if(Build.VERSION.SDK_INT>=34) {
                    ActivityOptions options=ActivityOptions.makeBasic();
                    options.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                    pi.send(this,0,null,null,null,null,options.toBundle());
                } else pi.send();
                finish();
            } else {
                Intent launch=getPackageManager().getLaunchIntentForPackage(sbn.getPackageName());
                if(launch!=null) { startActivity(launch); finish(); } else Ui.toast(this,"Is notification mein open action nahi hai.");
            }
        } catch(PendingIntent.CanceledException | RuntimeException e) { Ui.toast(this,"Notification expire ho gayi. App seedha kholein."); }
    }
    @Override protected void onResume() {
        super.onResume(); NotificationBridge.observers.add(notificationUpdate);
        if(body!=null) { if(notifications) showNotifications(); else showControls(); }
    }
    @Override protected void onPause() { NotificationBridge.observers.remove(notificationUpdate); super.onPause(); }
    @Override protected void onDestroy() {
        NotificationBridge.observers.remove(notificationUpdate);
        if(camera!=null && torchRegistered) camera.unregisterTorchCallback(torchCallback);
        if(Build.VERSION.SDK_INT>=31 && blurListener!=null) try { getWindowManager().removeCrossWindowBlurEnabledListener(blurListener); } catch(RuntimeException ignored) { }
        super.onDestroy();
    }
    private void close() {
        if(closing) return; closing=true;
        root.animate().alpha(0).translationY(-Ui.dp(this,18)).setDuration(160).withEndAction(this::finish).start();
    }
    @Override public void onBackPressed() { close(); }
}
