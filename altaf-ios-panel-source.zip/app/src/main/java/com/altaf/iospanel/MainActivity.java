package com.altaf.iospanel;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(0xff101625);
        LinearLayout root = Ui.column(this); root.setPadding(Ui.dp(this,24),Ui.dp(this,48),Ui.dp(this,24),Ui.dp(this,32));
        scroll.addView(root); setContentView(scroll);
        root.addView(Ui.text(this,"ALTAF / PERSONAL EDITION",12,true)); Ui.gap(root,18);
        root.addView(Ui.text(this,"Your phone.\nA calmer panel.",32,true)); Ui.gap(root,12);
        root.addView(Ui.text(this,"Pehle permissions allow karein. Phir Start dabayein. Right edge ki blue line ko tap ya left swipe karein.",16,false)); Ui.gap(root,22);
        status = Ui.text(this,"",14,false); root.addView(status); Ui.gap(root,20);
        root.addView(Ui.button(this,"1   Allow floating panel", () -> open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())))));
        root.addView(Ui.button(this,"2   Allow notification access", () -> open(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        root.addView(Ui.button(this,"3   Allow brightness control", () -> open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:"+getPackageName())))));
        root.addView(Ui.button(this,"4   Allow app notifications", () -> {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            else Ui.toast(this,"Notification permission ready");
        }));
        root.addView(Ui.button(this,"Start floating panel", this::startPanel));
        root.addView(Ui.button(this,"Open panel now", () -> startActivity(new Intent(this,PanelActivity.class))));
        root.addView(Ui.button(this,"Stop floating panel", () -> { stopService(new Intent(this,HandleService.class)); refresh(); }));
        Ui.gap(root,12);
        root.addView(Ui.text(this,"Wi-Fi, Bluetooth aur mobile data buttons asli system settings kholte hain. Brightness aur media volume sliders seedha kaam karte hain.\n\nBlur supported phones par milega; baaki par translucent background. Notifications phone par hi rehti hain.\n\nPhone restart ke baad app kholkar Start karein. Vivo par background battery restrictions service band kar sakti hain.",14,false));
    }
    void open(Intent i) { try { startActivity(i); } catch (RuntimeException e) { Ui.toast(this,"Settings nahi khuli. Phone Settings se permission dein."); } }
    void startPanel() {
        if (!Settings.canDrawOverlays(this)) { Ui.toast(this,"Pehle floating panel permission allow karein."); return; }
        try { startForegroundService(new Intent(this,HandleService.class)); Ui.toast(this,"Right edge par blue handle aa jayega."); }
        catch (RuntimeException e) { Ui.toast(this,"Panel start nahi hua: "+e.getClass().getSimpleName()); }
    }
    @Override protected void onResume() { super.onResume(); refresh(); }
    void refresh() {
        if(status==null) return;
        String enabled = Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        boolean listener = enabled != null && enabled.contains(new ComponentName(this,NotificationBridge.class).flattenToString());
        status.setText("Floating panel: "+(Settings.canDrawOverlays(this)?"Allowed":"Needed")+"\nNotifications: "+(listener?"Allowed":"Needed")+"\nBrightness: "+(Settings.System.canWrite(this)?"Allowed":"Optional"));
    }
}
