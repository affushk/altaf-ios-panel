package com.altaf.iospanel;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

final class Ui {
    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static GradientDrawable bg(Context c, int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(c, radius)); return d;
    }
    static TextView text(Context c, String s, int size, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    static LinearLayout column(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }
    static TextView button(Context c, String label, Runnable action) {
        TextView b = text(c, label, 16, true); b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16)); b.setBackground(bg(c, 0xff25354d, 18));
        b.setMinHeight(dp(c, 56)); b.setOnClickListener(v -> action.run()); b.setFocusable(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(c, 10); b.setLayoutParams(p); return b;
    }
    static void gap(LinearLayout l, int height) { View v = new View(l.getContext()); l.addView(v, new LinearLayout.LayoutParams(1, dp(l.getContext(), height))); }
    static void toast(Context c, String msg) { Toast.makeText(c, msg, Toast.LENGTH_LONG).show(); }
}
