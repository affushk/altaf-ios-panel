package com.altaf.iospanel;

import android.os.Handler;
import android.os.Looper;
import android.service.notification.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArraySet;

public class NotificationBridge extends NotificationListenerService {
    private static final Map<String,StatusBarNotification> items = new HashMap<>();
    static final Set<Runnable> observers = new CopyOnWriteArraySet<>();
    static volatile NotificationBridge instance;
    static List<StatusBarNotification> snapshot() {
        synchronized(items) { List<StatusBarNotification> list = new ArrayList<>(items.values()); list.sort((a,b)->Long.compare(b.getPostTime(),a.getPostTime())); return list; }
    }
    static void changed() { new Handler(Looper.getMainLooper()).post(() -> { for(Runnable r: observers) r.run(); }); }
    @Override public void onListenerConnected() {
        instance = this;
        synchronized(items) {
            items.clear();
            try { StatusBarNotification[] all = getActiveNotifications(); if(all!=null) for(StatusBarNotification n:all) items.put(n.getKey(),n); }
            catch(SecurityException ignored) { }
        }
        changed();
    }
    @Override public void onNotificationPosted(StatusBarNotification n) { synchronized(items) { items.put(n.getKey(),n); } changed(); }
    @Override public void onNotificationRemoved(StatusBarNotification n) { synchronized(items) { items.remove(n.getKey()); } changed(); }
    @Override public void onListenerDisconnected() { clear(); }
    @Override public void onDestroy() { clear(); super.onDestroy(); }
    private void clear() { instance=null; synchronized(items) { items.clear(); } changed(); }
    static void dismiss(String key) { NotificationBridge s=instance; if(s!=null) try { s.cancelNotification(key); } catch(SecurityException ignored) { } }
}
