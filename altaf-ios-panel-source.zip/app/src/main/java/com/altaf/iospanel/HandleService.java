package com.altaf.iospanel;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;

public class HandleService extends Service {
    private WindowManager wm; private View handle; private boolean receiverRegistered;
    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { updateVisibility(); }
    };
    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("panel", "Floating panel", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,HandleService.class).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,"panel").setSmallIcon(R.drawable.ic_status).setContentTitle("Altaf panel is ready")
            .setContentText("Tap the blue right-edge handle to open").setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(null,"Stop panel",stop).build()).build();
        try {
            if(Build.VERSION.SDK_INT>=34) startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE); else startForeground(1,n);
        } catch(RuntimeException e) { stopSelf(); return; }
        wm=getSystemService(WindowManager.class);
        IntentFilter filter=new IntentFilter(); filter.addAction(Intent.ACTION_SCREEN_OFF); filter.addAction(Intent.ACTION_SCREEN_ON); filter.addAction(Intent.ACTION_USER_PRESENT);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(screen,filter,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(screen,filter);
        receiverRegistered=true;
    }
    @Override public int onStartCommand(Intent i,int flags,int id) {
        if(i!=null && "STOP".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if(!Settings.canDrawOverlays(this) || wm==null) { stopSelf(); return START_NOT_STICKY; }
        if(handle==null) {
            handle=new View(this); handle.setContentDescription("Open Altaf control panel"); handle.setBackground(Ui.bg(this,0xcc8dc5ff,8));
            WindowManager.LayoutParams p=new WindowManager.LayoutParams(Ui.dp(this,14),Ui.dp(this,92),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
            p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;
            handle.setOnClickListener(v->openPanel());
            handle.setOnTouchListener(new View.OnTouchListener() {
                float x,y;
                @Override public boolean onTouch(View v,MotionEvent e) {
                    if(e.getAction()==MotionEvent.ACTION_DOWN) { x=e.getRawX(); y=e.getRawY(); return true; }
                    if(e.getAction()==MotionEvent.ACTION_UP) {
                        float dx=e.getRawX()-x,dy=e.getRawY()-y;
                        if(dx < -Ui.dp(HandleService.this,24) || (Math.abs(dx)<Ui.dp(HandleService.this,16)&&Math.abs(dy)<Ui.dp(HandleService.this,16))) v.performClick();
                        return true;
                    }
                    return true;
                }
            });
            try { wm.addView(handle,p); updateVisibility(); } catch(RuntimeException e) { handle=null; stopSelf(); }
        }
        return START_NOT_STICKY;
    }
    private void updateVisibility() {
        if(handle==null) return;
        boolean locked=getSystemService(KeyguardManager.class).isKeyguardLocked();
        boolean on=getSystemService(PowerManager.class).isInteractive();
        handle.setVisibility(locked || !on ? View.GONE : View.VISIBLE);
    }
    private void openPanel() {
        if(getSystemService(KeyguardManager.class).isKeyguardLocked()) return;
        try { startActivity(new Intent(this,PanelActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP)); }
        catch(RuntimeException e) { Ui.toast(this,"App kholkar Open panel now dabayein."); }
    }
    @Override public void onDestroy() {
        if(handle!=null && wm!=null) { try { wm.removeView(handle); } catch(RuntimeException ignored) { } handle=null; }
        if(receiverRegistered) unregisterReceiver(screen);
        stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
