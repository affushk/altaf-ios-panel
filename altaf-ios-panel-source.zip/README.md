# Altaf iOS Panel — personal Android app

Native Java app, Android 8.0+; application ID `com.altaf.iospanel`.

## Phone se GitHub par build

1. Repository root mein `altaf-ios-panel-source.zip` upload karein. ZIP extract na karein.
2. Add file → Create new file. Name exactly `.github/workflows/build-apk.yml`.
3. Di hui build-apk.yml ka poora content paste karke Commit changes karein.
4. Actions → Build Altaf APK → latest run. Green tick ka wait karein.
5. Run ke neeche Artifacts → Altaf-iOS-Panel-APK download karein.
6. Downloaded artifact ZIP extract karke app-debug.apk install karein.

Workflow manually bhi Actions → Build Altaf APK → Run workflow se chala sakte hain.
APK sirf successful compile AND lint ke baad artifact mein aayegi.
Har hosted build ka debug signing key badal sakta hai: update install conflict aaye
to purani Altaf iOS Panel app uninstall karein, phir nayi install aur permissions dein.
Purani altaf-notify alag app ho sakti hai: uska floating panel stop rakhein.

## Setup

App kholein → floating panel permission → notification access → optional brightness
permission → app notifications → Start floating panel. Right edge center ki blue line
tap ya left swipe karein. Open panel now bina overlay permission preview kholta hai.
Notifications tab mein real notifications hain. Tap se supplied notification action
khulta hai, Dismiss sirf clearable notifications remove karta hai.

Android 13+ par notification access greyed out ho to app info → three dots →
Allow restricted settings (agar phone par available ho), phir access allow karein.
Vivo par battery/background app settings service stop kar sakti hain; us situation
mein is app ko background mein run karne dein. Restart ke baad Start dobara dabayein.

## Actual controls and limits

- Brightness: system setting; user permission required; dragging selects manual mode.
- Volume: real media volume. Flashlight: camera permission, hardware availability.
- Wi-Fi, Bluetooth, data, airplane mode, DND: labeled links to actual Android settings.
  App unrestricted one-tap network toggles ka claim nahi karti.
- On Android 12+ devices with cross-window blur support, panel requests blur behind.
  Otherwise, including power-saving cases, readable translucent dark background.
- Blue edge handle opens the panel; this does not replace Android's status bar,
  secure lock screen, or system notification shade. Handle hides while locked.
- Screen capture is not blocked by this app. Use Power + Volume Down; a protected
  underlying app or phone policy can still affect the captured background.
- No notification text is uploaded or saved to disk. No INTERNET permission.
- Notifications depend on listener access; sensitive content can be redacted by Android.
- No automatic restart, accessibility service, or screen recording permission.

## Validation and first device check

Preparation checks passed: Java syntax, XML parsing, workflow structure, and Java compilation against the official Android API 35 android.jar (generated-resource ID stub only). APK packaging and Android lint have not run locally. GitHub workflow
performs the authoritative Android build and lint. A successful build is not a
phone runtime test. Check these on the actual phone:

1. Launcher opens even before permissions. Denying optional permissions does not crash.
2. Start shows one handle; repeated Start does not duplicate it; Stop removes it.
3. Tap/left swipe opens; Close and Back exit; repeat 10 times to check responsiveness.
4. Send a message from another phone; notification appears and tap opens the app.
5. Volume, brightness (with permission), network settings and flashlight work.
6. Power + Volume Down while panel open captures it on supported phone software.
7. Lock hides handle; unlock restores it. Reopen app after restart and tap Start.

## Technical references

- Android foreground service types: https://developer.android.com/develop/background-work/services/fgs/service-types
- Window blur: https://developer.android.com/reference/android/view/Window
- Settings panels: https://developer.android.com/reference/android/provider/Settings.Panel
- GitHub manual workflows: https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow

Build: Java 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2, SDK 35.
This is a personal debug APK project, not a Play Store release package.
